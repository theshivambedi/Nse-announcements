from .main import NseFetch, ProgramKilled

__all__ = ["NseFetch", "ProgramKilled"]


def hello():
    return "Hello from nse-announcements!"
